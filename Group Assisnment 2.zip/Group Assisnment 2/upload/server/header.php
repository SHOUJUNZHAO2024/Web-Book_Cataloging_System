<header>
    <h1>Book Cataloging System</h1>
    <div class="tagline">Discover Your Next Favorite Book!</div>
</header>