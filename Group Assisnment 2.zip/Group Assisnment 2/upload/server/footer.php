<footer>
    <p>&copy; 2024 We are the Best Web Group</p>
</footer>